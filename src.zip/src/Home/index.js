import React, { Component } from 'react'

class Home extends Component {
  render() {
    <div>
      <h1 className="py-3"> Home-- index.js </h1>
    </div>
  }
}

export default Home
